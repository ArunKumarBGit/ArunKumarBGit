#include "arrcus_tcam.h"

int
main (void)
{
    void *tcam_p = NULL;
    int ret_val = 0;
    entry_t tst_entry_1[] = {{4, 400}, {2, 200}, {3, 300}, {1, 100}};
    entry_t tst_entry_2[] = {{6, 600}, {5, 500}};
    entry_t tst_entry_3[] = {{9, 900}, {10, 1000}, {8, 800}, {7, 700}, 
                             {14, 1400}};
    entry_t tst_entry_4[] = {{15, 200}};
    entry_t tst_entry_5[] = {{16, 150}};
    entry_t tst_entry_6[] = {{17, 650}};
    entry_t tst_entry_7[] = {{18, 99}};
    entry_t tst_entry_8[] = {{19, 44}};
    entry_t tst_entry_9[] = {{20, 1500}};
    entry_t tst_entry_10[] = {{21, 999}};

    ret_val = tcam_init(10, &tcam_p);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to initialize TCAM");
    }

    tcam_handle_disp(tcam_p);
    tcam_entries_disp(tcam_p);

    ret_val = tcam_insert(tcam_p, tst_entry_1,
                          (sizeof(tst_entry_1)/sizeof(tst_entry_1[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }

    tcam_handle_disp(tcam_p);
    tcam_vld_entries_disp(tcam_p);

    ret_val = tcam_insert(tcam_p, tst_entry_2,
                          (sizeof(tst_entry_2)/sizeof(tst_entry_2[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }

    tcam_handle_disp(tcam_p);
    tcam_vld_entries_disp(tcam_p);

    ret_val = tcam_insert(tcam_p, tst_entry_3,
                          (sizeof(tst_entry_3)/sizeof(tst_entry_3[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }

    tcam_remove(tcam_p, 2);
    ret_val = tcam_insert(tcam_p, tst_entry_3,
                          (sizeof(tst_entry_3)/sizeof(tst_entry_3[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }
    tcam_handle_disp(tcam_p);
    tcam_vld_entries_disp(tcam_p);

    tcam_remove(tcam_p, 3);
    ret_val = tcam_insert(tcam_p, tst_entry_4,
                          (sizeof(tst_entry_4)/sizeof(tst_entry_4[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }
    tcam_handle_disp(tcam_p);
    tcam_vld_entries_disp(tcam_p);

    tcam_remove(tcam_p, 10);
    ret_val = tcam_insert(tcam_p, tst_entry_5,
                          (sizeof(tst_entry_5)/sizeof(tst_entry_5[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }
    tcam_handle_disp(tcam_p);
    tcam_vld_entries_disp(tcam_p);

    tcam_remove(tcam_p, 1);
    tcam_remove(tcam_p, 8);
    ret_val = tcam_insert(tcam_p, tst_entry_6,
                          (sizeof(tst_entry_6)/sizeof(tst_entry_6[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }
    tcam_handle_disp(tcam_p);
    tcam_entries_disp(tcam_p);

    ret_val = tcam_insert(tcam_p, tst_entry_7,
                          (sizeof(tst_entry_7)/sizeof(tst_entry_7[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }
    tcam_remove(tcam_p, 7);
    tcam_handle_disp(tcam_p);
    tcam_entries_disp(tcam_p);
    ret_val = tcam_insert(tcam_p, tst_entry_8,
                          (sizeof(tst_entry_8)/sizeof(tst_entry_8[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }
    tcam_handle_disp(tcam_p);
    tcam_entries_disp(tcam_p);

    tcam_remove(tcam_p, 6);
    tcam_handle_disp(tcam_p);
    tcam_entries_disp(tcam_p);
    ret_val = tcam_insert(tcam_p, tst_entry_9,
                          (sizeof(tst_entry_9)/sizeof(tst_entry_9[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }
    tcam_handle_disp(tcam_p);
    tcam_entries_disp(tcam_p);

    tcam_remove(tcam_p, 5);
    tcam_handle_disp(tcam_p);
    tcam_entries_disp(tcam_p);
    ret_val = tcam_insert(tcam_p, tst_entry_10,
                          (sizeof(tst_entry_10)/sizeof(tst_entry_10[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    }
    tcam_handle_disp(tcam_p);
    tcam_entries_disp(tcam_p);

    // Clean up
    tcam_destroy(tcam_p);

    return(SUCCESS);
}

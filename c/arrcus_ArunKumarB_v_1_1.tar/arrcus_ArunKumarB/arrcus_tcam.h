#ifndef _ARRCUS_TCAM_H_
#define _ARRCUS_TCAM_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "arrcus_tcam_defs.h"
#include "arrcus_tcam_intf.h"
#include "arrcus_tcam_debug.h"

// Internal utility APIs
int tcam_sort_entries(entry_t *entries_p, uint32_t num);
int tcam_add_entries(tcam_handle_t *tcam_handle_p, entry_t *entries_p, 
                     uint32_t num);
int tcam_stats_disp(void *tcam_p);
int tcam_handle_disp(void *tcam_p);
int tcam_entries_disp(void *tcam_p);
int tcam_vld_entries_disp(void *tcam_p);
int tcam_destroy(void *tcam_p);

#endif

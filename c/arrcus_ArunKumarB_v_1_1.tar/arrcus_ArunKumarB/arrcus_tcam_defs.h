#ifndef _ARRCUS_TCAM_DEFS_H_
#define _ARRCUS_TCAM_DEFS_H_

#define DISPLAY(fmt, arg...)        printf(fmt"\n", ##arg)
#define DISPLAY_ACK(fmt, arg...)    \
{                                   \
printf("\n"fmt, ##arg);             \
getchar();                          \
}

#define TCAM_SIZE_MAX               2048
#define ARGV_STR_LEN_MAX            5
#define ARGV_STR_STATIC_UT          "-st"
#define ARGV_STR_DYNAMIC_UT         "-dt"
#define ARGV_OPTION_INDEX           1
#define TCAM_ENTRY_VALID            1
#define TCAM_ENTRY_EMPTY            0
#define SUCCESS                     0
#define TRUE                        1
#define FALSE                       0

typedef struct entry_ {
    uint32_t id;        // Must be unique, 0 means empty TCAM entry
    uint32_t prio;      // 0 means the highest priority
} entry_t;

typedef struct tcam_handle_ {
    entry_t *base_p;
    uint32_t sz;
    uint32_t vld_entries;
    uint32_t last_hw_access;
    //uint64_t total_hw_access;
    uint64_t hw_access;
} tcam_handle_t;

#endif

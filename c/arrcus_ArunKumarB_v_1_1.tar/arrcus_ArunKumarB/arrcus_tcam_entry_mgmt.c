#include "arrcus_tcam.h"

int
tcam_init (uint32_t size, void **tcam_pp)
//tcam_init (entry_t *hw_tcam_p, uint32_t size, void **tcam_pp)
{
    entry_t *tcam_p              = NULL;
    tcam_handle_t *tcam_handle_p = NULL;

    if (tcam_pp == NULL) {
    //if ((hw_tcam_p == NULL) || (tcam_pp == NULL)) {
        ARRCUS_TCAM_ERR("NULL parameter passed for tcam_pp");
        return(ARRCUS_TCAM_ERR_NULL_PARAM);
    }

    if (size == 0) {
        ARRCUS_TCAM_ERR("Invalid size passed");
        return(ARRCUS_TCAM_ERR_INVALID_PARAM);
    }

    // Allocate memory for TCAM
    tcam_p = (entry_t *)malloc(size * sizeof(entry_t));
    if (tcam_p == NULL) {
        ARRCUS_TCAM_ERR("Failed to allocate memory for TCAM, size '%lu'",
                        (size * sizeof(entry_t)));
        return(ARRCUS_TCAM_ERR_MALLOC_FAILED);
    }

    memset(tcam_p, 0, (size * sizeof(entry_t)));

    // Allocate memory for TCAM handle
    tcam_handle_p = (tcam_handle_t *)malloc(sizeof(tcam_handle_t));
    if (tcam_handle_p == NULL) {
        ARRCUS_TCAM_ERR("Failed to allocate memory for TCAM handle, size '%lu'",
                        sizeof(tcam_handle_t));
        return(ARRCUS_TCAM_ERR_MALLOC_FAILED);
    }

    tcam_handle_p->base_p = tcam_p;
    tcam_handle_p->sz = size;
    tcam_handle_p->vld_entries = 0;
    tcam_handle_p->hw_access = 0;
    tcam_handle_p->last_hw_access = 0;

    *tcam_pp = tcam_handle_p;

    return(SUCCESS);
}


int 
tcam_insert (void *tcam_p, entry_t *entries_p, uint32_t num)
{
    tcam_handle_t *tcam_handle_p    = tcam_p;
    uint32_t avbl_sz                = 0;

    if ((tcam_p == NULL) || (entries_p == NULL)) {
        ARRCUS_TCAM_ERR("NULL parameter passed. tcam_p = '%p', entries_p = '%p'",
                        tcam_p, entries_p);
        return(ARRCUS_TCAM_ERR_NULL_PARAM);
    }

    if (num == 0) {
        ARRCUS_TCAM_ERR("Invalid number of entries '%d'", num);
        return(ARRCUS_TCAM_ERR_INVALID_PARAM);
    }

    avbl_sz = tcam_handle_p->sz - tcam_handle_p->vld_entries;

    if (avbl_sz < num) {
        ARRCUS_TCAM_ERR("Available TCAM space '%d' is less than required '%d' space",
                        avbl_sz, num);
        return(ARRCUS_TCAM_ERR_TCAM_NO_SPACE);
    }

    return(tcam_add_entries(tcam_handle_p, entries_p, num));
}


int 
tcam_remove (void *tcam_p, uint32_t id)
{
    tcam_handle_t *tcam_handle_p    = tcam_p;
    uint32_t i                      = 0;
    char is_deleted                 = 0;

    if (tcam_p == NULL) {
        ARRCUS_TCAM_ERR("NULL parameter passed for tcam_p");
        return(ARRCUS_TCAM_ERR_NULL_PARAM);
    }

    if (id == 0) {
        ARRCUS_TCAM_ERR("Invalid value passed for id '%d'", id);
        return(ARRCUS_TCAM_ERR_INVALID_PARAM);
    }

    tcam_handle_p->last_hw_access = 0;

    for (i = 0; i < tcam_handle_p->sz; i++) {
        if ((tcam_handle_p->base_p + i)->id == id) {
            (tcam_handle_p->base_p + i)->id = 0;
            (tcam_handle_p->base_p + i)->prio = 0;
            tcam_handle_p->vld_entries--;
            tcam_handle_p->hw_access++;
            tcam_handle_p->last_hw_access++;
            is_deleted = 1;
            break;
        }
    }

    if (is_deleted == 0) {
        ARRCUS_TCAM_ERR("No entry found in TCAM with id '%d'", id);
        return(ARRCUS_TCAM_ERR_REMOVE_FAILED);
    }

    return(SUCCESS);
}

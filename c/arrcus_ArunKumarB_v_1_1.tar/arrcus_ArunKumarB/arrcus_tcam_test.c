#include "arrcus_tcam.h"

//static entry_t hw_tcam[TCAM_SIZE_MAX];
#if defined(ENABLE_CONSOLE_ERR_LOG)
bool console_err_en = TRUE;
#else
bool console_err_en = FALSE;
#endif

#if defined(ENABLE_CONSOLE_TRC_LOG)
bool console_trc_en = TRUE;
#else
bool console_trc_en = FALSE;
#endif

int
arrcus_tcam_static_test()
{
    void *tcam_p            = NULL;
    uint32_t size           = 10;
    unsigned char sno       = 0;
    int ret_val             = 0;
    entry_t tst_entry_1[]   = {{4, 400}, {2, 200}, {3, 300}, {1, 100}};
    entry_t tst_entry_2[]   = {{6, 600}, {5, 500}};
    entry_t tst_entry_3[]   = {{9, 900}, {10, 1000}, {8, 800}, {7, 700}, 
                               {14, 1400}};
    entry_t tst_entry_4[]   = {{15, 200}};
    entry_t tst_entry_5[]   = {{16, 150}};
    entry_t tst_entry_6[]   = {{17, 650}};
    entry_t tst_entry_7[]   = {{18, 99}};
    entry_t tst_entry_8[]   = {{19, 44}};
    entry_t tst_entry_9[]   = {{20, 1500}};
    entry_t tst_entry_10[]  = {{21, 999}};

    DISPLAY_ACK("%2d of 21) Press ENTER ... To initialize TCAM of size '%u'", 
                ++sno, size);
    ret_val = tcam_init(10, &tcam_p);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to initialize TCAM");
    } else {
        DISPLAY("\t  TCAM initiatlized successfully");
        tcam_stats_disp(tcam_p);
        tcam_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_1)/sizeof(tst_entry_1[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_1,
                          (sizeof(tst_entry_1)/sizeof(tst_entry_1[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_2)/sizeof(tst_entry_2[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_2,
                          (sizeof(tst_entry_2)/sizeof(tst_entry_2[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_3)/sizeof(tst_entry_3[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_3,
                          (sizeof(tst_entry_3)/sizeof(tst_entry_3[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To remove entry with id '%d'", ++sno, 2);
    ret_val = tcam_remove(tcam_p, 2);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to remove TCAM entry with id '%d'", 2);
    } else {
        DISPLAY("\t  TCAM removal successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_3)/sizeof(tst_entry_3[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_3,
                          (sizeof(tst_entry_3)/sizeof(tst_entry_3[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To remove entry with id '%d'", ++sno, 3);
    ret_val = tcam_remove(tcam_p, 3);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to remove TCAM entry with id '%d'", 3);
    } else {
        DISPLAY("\t  TCAM removal successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_4)/sizeof(tst_entry_4[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_4,
                          (sizeof(tst_entry_4)/sizeof(tst_entry_4[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To remove entry with id '%d'", ++sno, 10);
    ret_val = tcam_remove(tcam_p, 10);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to remove TCAM entry with id '%d'", 10);
    } else {
        DISPLAY("\t  TCAM removal successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_5)/sizeof(tst_entry_5[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_5,
                          (sizeof(tst_entry_5)/sizeof(tst_entry_5[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To remove entry with id '%d', '%d'", 
                ++sno, 1, 8);
    ret_val = tcam_remove(tcam_p, 1);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to remove TCAM entry with id '%d'", 10);
    }
    ret_val = tcam_remove(tcam_p, 8);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to remove TCAM entry with id '%d'", 10);
    } else {
        DISPLAY("\t  TCAM removal successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_6)/sizeof(tst_entry_6[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_6,
                          (sizeof(tst_entry_6)/sizeof(tst_entry_6[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_7)/sizeof(tst_entry_7[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_7,
                          (sizeof(tst_entry_7)/sizeof(tst_entry_7[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }
    
    DISPLAY_ACK("%2d of 21) Press ENTER ... To remove entry with id '%d'", ++sno, 7);
    ret_val = tcam_remove(tcam_p, 7);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to remove TCAM entry with id '%d'", 7);
    } else {
        DISPLAY("\t  TCAM removal successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_8)/sizeof(tst_entry_8[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_8,
                          (sizeof(tst_entry_8)/sizeof(tst_entry_8[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To remove entry with id '%d'", ++sno, 6);
    ret_val = tcam_remove(tcam_p, 6);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to remove TCAM entry with id '%d'", 6);
    } else {
        DISPLAY("\t  TCAM removal successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_9)/sizeof(tst_entry_9[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_9,
                          (sizeof(tst_entry_9)/sizeof(tst_entry_9[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To remove entry with id '%d'", ++sno, 5);
    ret_val = tcam_remove(tcam_p, 5);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to remove TCAM entry with id '%d'", 5);
    } else {
        DISPLAY("\t  TCAM removal successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To insert batch of '%lu' entries",
                ++sno, (sizeof(tst_entry_10)/sizeof(tst_entry_10[0])));
    ret_val = tcam_insert(tcam_p, tst_entry_10,
                          (sizeof(tst_entry_10)/sizeof(tst_entry_10[0])));
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to insert entries to TCAM");
    } else {
        DISPLAY("\t  TCAM insertion successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To remove entry with id '%d'", ++sno, 49);
    ret_val = tcam_remove(tcam_p, 49);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to remove TCAM entry with id '%d'", 5);
    } else {
        DISPLAY("\t  TCAM removal successful");
        tcam_stats_disp(tcam_p);
        tcam_vld_entries_disp(tcam_p);
    }

    DISPLAY_ACK("%2d of 21) Press ENTER ... To destroy TCAM and releae memory", ++sno);
    ret_val = tcam_destroy(tcam_p);
    if (ret_val != SUCCESS) {
        ARRCUS_TCAM_ERR("Failed to destroy TCAM");
    } else {
        DISPLAY("\t  TCAM destroyed successful\n");
    }

    return(SUCCESS);
}


int
arrcus_tcam_dynamic_test ()
{
    DISPLAY_ACK("Welcome to dynamic test suite");

    return(SUCCESS);
}

int
main (int argc, char *argv[])
{
    if (argc == 2) {
        if (strncmp(argv[ARGV_OPTION_INDEX], ARGV_STR_STATIC_UT, 
                    ARGV_STR_LEN_MAX) == 0) {
        return(arrcus_tcam_static_test());
        } else if (strncmp(argv[ARGV_OPTION_INDEX], ARGV_STR_DYNAMIC_UT, 
                           ARGV_STR_LEN_MAX) == 0) {
        return(arrcus_tcam_dynamic_test());
        } 
    }

    DISPLAY("\n./tcam --help to display this help message");
    DISPLAY("Available options:");
    DISPLAY("   -st     Execute static test cases, having 21 UT cases");
    DISPLAY("   -dt     Execute dynamic test cases, user driven\n");
    DISPLAY("Example:\n   ./tcam -st\n   ./tcam -dt\n");

    return(SUCCESS);
}

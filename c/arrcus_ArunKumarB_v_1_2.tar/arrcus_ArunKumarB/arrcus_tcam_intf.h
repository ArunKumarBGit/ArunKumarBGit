#ifndef _ARRCUS_TCAM_INTF_H_
#define _ARRCUS_TCAM_INTF_H_

/* Initialize a TCAM bank handler serving the given hw_tcam,
* returns 0 in case of success and a pointer to the handler
*/
//int tcam_init(uint32_t size, void **tcam);
int tcam_init(entry_t *hw_tcam, uint32_t size, void **tcam);

/* Insert a batch of entries into the TCAM referred by ‘tcam’
* returns 0 in case of success and some meaningful error code otherwise (define the API).
* Ideally the insert is either successful entirely or it fails and nothing is inserted.
* At least handle table full gracefully, ie. return an error when the batch would not fit and
* do not insert partial batches.
* TCAM entries present _before_ the call must always be in effect during the batch insertion
* (i.e, no traffic hit).
* The  order of new entries in the batch and the order they take effect is undefined. Please
* elaborate on the expected behavior in case of your implementation.
*/
int tcam_insert(void *tcam, entry_t *entries, uint32_t num);


/* Remove the entry referred by ID if that exists from the TCAM referred by ‘tcam’
* returns 0 in case of success and some meaningful error code otherwise (define the API).
*/
int tcam_remove(void *tcam, uint32_t id);

#endif

/********************************************************************
 *
 * File: arrcus_tcam.h
 * Name: Arun Kumar B (arunkumar.be@gmail.com)
 *
 * Description:
 *  This file contains declaration of southbound API, utility APIs
 *  and consolidated header files list
 *
 * Copyright (c) 2022 by Arrcus, Inc.
 * All rights reserved.
 *
 ********************************************************************/
#ifndef _ARRCUS_TCAM_H_
#define _ARRCUS_TCAM_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "arrcus_tcam_defs.h"
#include "arrcus_tcam_intf.h"
#include "arrcus_tcam_debug.h"
#include "arrcus_tcam_test.h"

// Southbound API, for TCAM write
int tcam_program(void *tcam_p, entry_t *ent_p, uint32_t position);

// Internal utility APIs
int tcam_sort_entries(entry_t *entries_p, uint32_t num);
int tcam_add_entries(tcam_handle_t *tcam_handle_p, entry_t *entries_p, 
                     uint32_t num);
int tcam_stats_disp(void *tcam_p);
int tcam_handle_disp(void *tcam_p);
int tcam_entries_disp(void *tcam_p);
int tcam_vld_entries_disp(void *tcam_p);
int tcam_handle_release(void **tcam_p);

#endif

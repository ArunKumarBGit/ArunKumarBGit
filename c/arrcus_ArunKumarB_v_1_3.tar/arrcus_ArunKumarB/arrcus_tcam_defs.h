/********************************************************************
 *
 * File: arrcus_tcam_defs.h
 * Name: Arun Kumar B (arunkumar.be@gmail.com)
 *
 * Description:
 *  This file contains data structures used for TCAM entry management
 *
 * Copyright (c) 2022 by Arrcus, Inc.
 * All rights reserved.
 *
 ********************************************************************/
#ifndef _ARRCUS_TCAM_DEFS_H_
#define _ARRCUS_TCAM_DEFS_H_

#define TCAM_SIZE_MAX       2048
#define TCAM_ENTRY_EMPTY    0

typedef struct entry_ {
    uint32_t id;        // Must be unique, 0 means empty TCAM entry
    uint32_t prio;      // 0 means the highest priority
} entry_t;

typedef struct tcam_handle_ {
    entry_t *tcam_p;
    uint32_t sz;
    uint32_t vld_entries;
    uint32_t last_hw_access;
    uint64_t total_hw_access;
} tcam_handle_t;

#endif

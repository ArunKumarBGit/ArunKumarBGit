/********************************************************************
 *
 * File: arrcus_tcam_test.h
 * Name: Arun Kumar B (arunkumar.be@gmail.com)
 *
 * Description:
 *  This file contains macros used for TCAM entry management Unit Test
 *
 * Copyright (c) 2022 by Arrcus, Inc.
 * All rights reserved.
 *
 ********************************************************************/
#ifndef _ARRCUS_TCAM_TEST_H_
#define _ARRCUS_TCAM_TEST_H_

#define DISPLAY(fmt, arg...)        printf(fmt"\n", ##arg)
#define DISPLAY_ACK(fmt, arg...)    \
{                                   \
printf("\n"fmt, ##arg);             \
getchar();                          \
}

#define ARGV_STR_LEN_MAX            5
#define ARGV_STR_STATIC_UT          "-st"
#define ARGV_STR_DYNAMIC_UT         "-dt"
#define ARGV_OPTION_INDEX           1

#endif
